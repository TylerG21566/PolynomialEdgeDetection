#include <stdio.h>
#include <opencv2/core/core.hpp>

int main(int argc, char *argv[])
{
	//Print the OpenCV version
	printf ("OpenCV version: %d.%d\n", CV_MAJOR_VERSION, CV_MINOR_VERSION);
	return 0;
}
