#include <stdio.h>
#include <opencv2/core/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>

int main(int argc, char *argv[])
{
	cv::Mat img;

	img = cv::imread(argv[1]);

	// Check if the image was successfully loaded
	if (img.empty()) {
			printf("Failed to load image '%s'\n", argv[1]);
			return -1;
	}

	// Invert the image
	for(int r = 0; r < img.rows; r++)
	{
		for (int c = 0; c < img.cols; c++)
		{
			cv::Vec3b px = img.at<cv::Vec3b>(r, c);
			px[0] = 0; // Blue
			px[1] = 0; // Green
			// Leave Red channel untouched
			img.at<cv::Vec3b>(r, c) = px;
		}
	}

	cv::namedWindow("Image", cv::WINDOW_NORMAL);
	cv::imshow("Image", img);

	// Wait for a key press before quitting
	cv::waitKey(0);

	cv::imwrite("red.jpg", img);

	return 0;
}
